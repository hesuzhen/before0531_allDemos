package com.zhjava.lesson2;

public class Test {
    /*一个景区根据游人的年龄收取不同价格的门票
    请编写游人测试类，根据年龄段决定能够购买的门票价格并输出*/
    public static void main(String[] args) {
        Traveler traveler = new Traveler();
        traveler.show();

    }
}
