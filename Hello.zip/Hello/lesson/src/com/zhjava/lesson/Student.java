package com.zhjava.lesson;

public class Student {
    String name;
    int id;
    String hobby;



}
